# COGENT PROJECT

### Run Instructions

git checkout map

python3 -m venv bds_visualization python==3.8.12
bds_visualization/bin/pip install -r src/pip_requirements.txt

sudo apt-get install python3-tk

python3 app.py

// NAVIGATE TP http://127.0.0.1:8051 //
